#include <stdio.h>
#include <stdlib.h>
#include "pila.h"

/**
UTN | Mar del Plata
-
Programaci�n 1
-
Laboratorio 1
Pr�ctico
3
-
Funciones
NOTA: todas las funciones pedidas deben recibir por par�metro la/s pila/s cargadas con los datos.
No se debe usar la funci�n leer() dentro de la funci�n, excepto en la funci�n 1
.
1. Hacer una funci�n que permita ingresar varios elementos a una Pila, tantos como quiera el
usuario.*/

void llenarPila(Pila*nombrePila){
    char control='s';
    while(control=='s'){
        leer(nombrePila);
        printf("desea continuar? S/N \n");
        fflush(stdin);
        scanf("%c",&control);
    }
}

/**2. Hacer una funci�n que pase todos los elementos de una pila a otra.*/

void pasarPila(Pila*p1, Pila*p2){
    while(!pilavacia(p1)){
        apilar(p2, desapilar(p1));
    }
}

/**3.  Hacer  una  funci�n  que  pase  todos  los  elementos  de  una  pila  a  otra,  pero  cons
ervando  el
orden.*/

void pasarPilaCons(Pila*a,Pila*c){
    Pila aux;
    inicpila(&aux);
    while(!pilavacia(a)){
        apilar(&aux, desapilar(a));
    }
    while(!pilavacia(&aux)){
        apilar(c,desapilar(&aux));
    }
}

/**4. Hacer una funci�n que encuentre el menor elemento de una pila y lo retorne.*/
int menorElemento(Pila*p){
    int menorElmt;
    Pila menor, aux;
    inicpila(&menor);
    inicpila(&aux);

    apilar(&menor, desapilar(p));
    while(!pilavacia(p)){
        if(tope(p) < tope(&menor)){
            apilar(&aux, desapilar(&menor));
            apilar(&menor, desapilar(p));
        }else{
            apilar(&aux, desapilar(p));
        }
    }

    pasarPila(&aux, p);
    menorElmt = tope(&menor);
    return menorElmt;
}
/**5. Hacer una funci�n que pase los elementos de una pila a otra, de manera que se genere una
nueva pila ordenada. Usar la funci�n del ejercicio 4.*/

void pasarOrdenando(Pila*p, Pila*q){
    while(!pilavacia(p)){
        apilar(q,menorElemento(p));
    }
}

/**6. Hacer una funci�n que inserte en una pila ordenada un nuevo elemento,
 conservando el orden de esta. */

void ubicarEn(int x, Pila*p){
    Pila aux;
    inicpila(&aux);

    apilar(p, x);
    pasarOrdenando(p, &aux);
    pasarOrdenando(&aux, p);

}

/**7. Hacer una funci�n que pase los elementos de una pila a otra, de manera que se genere una
nueva pila ordenada. Usar la funci�n del ejercicio 6.
*/

void ubicarPila(Pila*p, Pila*q){
    Pila aux;
    inicpila(&aux);

    while(!pilavacia(q)){
        apilar(&aux,desapilar(q));
    }
    pasarOrdenando(&aux,q);
    while(!pilavacia(p)){
        ubicarEn(desapilar(p), q);
    }
}
/**8. Hacer una funci�n que sume y retorne los dos primeros elementos de una pila
(tope y anterior), sin alterar su contenido*/

int sumDosPrimEl(Pila p){
    int suma;
    Pila aux;
    inicpila(&aux);

    if(!pilavacia(&p)){
        apilar(&aux, desapilar(&p));
    } else {
        printf("La pila esta vacia\n");
    }

    if(!pilavacia(&p)){
        suma = tope(&p) + tope(&aux);
    } else {
        suma = 0 + tope(&aux);
    }
    return suma;
}

/**9. Hacer una funci�n que calcule el promedio de los elementos de una pila,
para ello hacer tambi�n una funci�n que calcule la suma, otra para la cuenta y
otra que divida. En total son cuatro funciones, y la funci�n que calcula el
promedio invoca a las otras 3.*/

int sumarPila(Pila p){
    int suma = 0;
    Pila aux;
    inicpila(&aux);
    while(!pilavacia(&p)){
        suma += tope(&p);
        apilar(&aux, desapilar(&p));
    }
    return suma;
}

int contarPila(Pila p){
    int i = 0;
    Pila aux;
    inicpila(&aux);
    while(!pilavacia(&p)){
        apilar(&aux, desapilar(&p));
        i++;
    }
    return i;
}
float dividir(int a, int b){
    float cociente;
    cociente = (float)a / (float)b;
    return cociente;
}
float promedioPila(Pila p){
    float promedio;
    if(!pilavacia(&p)){
        promedio = dividir(sumarPila(p),contarPila(p));
    } else {
        promedio = 0;
    }
    return promedio;
}

/**10
. Hacer una funci�n que reciba una pila con n�meros de un solo d�gito
(es responsabilidad
de quien usa el programa) y que transforme esos
d�gitos en un n�mero decimal. Por ejemplo,
la pila: Debe retornar el n�mero: 14675*/

int convertirPilaEnInt(Pila p){
    int num = 0, numAux = 0;


    while(!pilavacia(&p)){
        num *= 10;
        numAux = desapilar(&p);
        num += numAux;
    }

    return num;
}


int main(){

    char control = 's';
    int elemento = 0;
    Pila pilerson, pilaPache, descarte;

    inicpila(&pilerson);
    inicpila(&pilaPache);
    inicpila(&descarte);

    int ejercicio = 0;
while(control == 's'){
        printf("Ejercicio 1: Ingresar varios elementos a una Pila \n");
        printf("Ejercicio 2: Pasar todos los elementos de una pila a otra\n");
        printf("Ejercicio 3: Pasar todos los elementos de una pila a otra, conservando orden\n");
        printf("Ejercicio 4: Encontrar el menor elemento de una pila\n");
        printf("Ejercicio 5: Pasar los elementos de una pila a otra, generando una nueva pila ordenada.\n");
        printf("Ejercicio 6: Insertar  en  una  pila  ordenada  un  nuevo  elemento,  conservando  el orden de esta.\n");
        printf("Ejercicio 7: Pasar los elementos de una pila a otra, de manera que se genere una nueva pila ordenada. \n");
        printf("Ejercicio 8: Sumar los  dos  primeros  elementos  de  una  pila \n");
        printf("Ejercicio 9: Calcule el promedio de los elementos de una pila\n");
        printf("Ejercicio 10: Cargar una pila con numeros de un solo digito  y transformar en un numero decimal.\n\n");
        printf("Elija un ejercicio: ");
        scanf("%d", &ejercicio);



    switch(ejercicio){

        case 1: while(!pilavacia(&pilerson)){
                    apilar(&descarte, desapilar(&pilerson));
                }
                while(!pilavacia(&pilaPache)){
                    apilar(&descarte, desapilar(&pilerson));
                }llenarPila(&pilerson);
                mostrar(&pilerson);

        break;

        case 2: while(!pilavacia(&pilerson)){
                    apilar(&descarte, desapilar(&pilerson));
                }
                while(!pilavacia(&pilaPache)){
                    apilar(&descarte, desapilar(&pilerson));
                }llenarPila(&pilerson);
                pasarPila(&pilerson, &pilaPache);
                mostrar(&pilaPache);

        break;

        case 3: while(!pilavacia(&pilerson)){
                    apilar(&descarte, desapilar(&pilerson));
                }
                while(!pilavacia(&pilaPache)){
                    apilar(&descarte, desapilar(&pilerson));
                }llenarPila(&pilerson);
                llenarPila(&pilaPache);
                pasarPilaCons(&pilaPache, &pilerson);
                mostrar(&pilaPache);
        break;

        case 4: while(!pilavacia(&pilerson)){
                    apilar(&descarte, desapilar(&pilerson));
                }
                while(!pilavacia(&pilaPache)){
                    apilar(&descarte, desapilar(&pilerson));
                }llenarPila(&pilerson);
                printf("Menor Elemento: %i\n",menorElemento(&pilerson));
                mostrar(&pilerson);
        break;

        case 5: while(!pilavacia(&pilerson)){
                    apilar(&descarte, desapilar(&pilerson));
                }
                while(!pilavacia(&pilaPache)){
                    apilar(&descarte, desapilar(&pilerson));
                }llenarPila(&pilerson);
                llenarPila(&pilaPache);
                pasarOrdenando(&pilerson, &pilaPache);
                mostrar(&pilaPache);
        break;

        case 6: while(!pilavacia(&pilerson)){
                    apilar(&descarte, desapilar(&pilerson));
                }
                while(!pilavacia(&pilaPache)){
                    apilar(&descarte, desapilar(&pilerson));
                }llenarPila(&pilerson);
                printf("Insertar elemento: ");
                scanf("%i", &elemento);
                ubicarEn(elemento, &pilerson);
                mostrar(&pilerson);
        break;

        case 7: while(!pilavacia(&pilerson)){
                    apilar(&descarte, desapilar(&pilerson));
                }
                while(!pilavacia(&pilaPache)){
                    apilar(&descarte, desapilar(&pilerson));
                }llenarPila(&pilaPache);
                llenarPila(&pilerson);
                ubicarPila(&pilerson, &pilaPache);
                mostrar(&pilaPache);
        break;

        case 8: while(!pilavacia(&pilerson)){
                    apilar(&descarte, desapilar(&pilerson));
                }
                while(!pilavacia(&pilaPache)){
                    apilar(&descarte, desapilar(&pilerson));
                }
                llenarPila(&pilerson);
                int suma = sumDosPrimEl(pilerson);
                printf("Suma de los dos primeros elementos: %i",suma);
                mostrar(&pilerson);
        break;

        case 9: while(!pilavacia(&pilerson)){
                    apilar(&descarte, desapilar(&pilerson));
                }
                while(!pilavacia(&pilaPache)){
                    apilar(&descarte, desapilar(&pilerson));
                }
                llenarPila(&pilerson);
                printf("Promedio de pilerson: %.2f\n", promedioPila(pilerson));
        break;

        case 10: while(!pilavacia(&pilerson)){
                    apilar(&descarte, desapilar(&pilerson));
                }
                while(!pilavacia(&pilaPache)){
                    apilar(&descarte, desapilar(&pilerson));
                }llenarPila(&pilerson);
                 printf("%i\n", convertirPilaEnInt(pilerson));
        break;


        default:
            printf("El Ejercicio no existe salame \n");
        break;
    }

    printf("Desea continuar, salame? s/n\n");
    fflush(stdin);
    scanf("%c", &control);
}

    return 0;
}
